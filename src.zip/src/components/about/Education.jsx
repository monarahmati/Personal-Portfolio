import React from "react";

const educationContent = [
  {
    year: "1392",
    degree: "مدرک مهندسی",
    institute: "دانشگاه آکسفورد",
    details: `لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است`,
  },
  {
    year: "1390",
    degree: "کارشناسی ارشد ",
    institute: "دانشگاه کیف",
    details: `لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است `,
  },
  {
    year: "1386",
    degree: "مدرک لیسانس ",
    institute: "دانشگاه تهران",
    details: `لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است `,
  },
];

const Education = () => {
  return (
    <ul>
      {educationContent.map((val, i) => (
        <li key={i}>
          <div className="icon">
            <i className="fa fa-briefcase"></i>
          </div>
          <span className="time open-sans-font text-uppercase"  style={{ marginRight:'2.5rem' , marginTop:'0.5rem'  }} >{val.year}</span>
          <h5 className="poppins-font text-uppercase">
            <span className="place open-sans-font"> {val.institute} </span>
            {val.degree}
          </h5>
          <p className="open-sans-font">{val.details}</p>
        </li>
      ))}
    </ul>
  );
};

export default Education;
